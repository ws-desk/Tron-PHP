<?php
require 'vendor/autoload.php';
require 'rsa.php';
use Elliptic\EC;
use \IEXBase\TronAPI\Tron;
try {
define('RSA_PRIVATE','./key_rsa/rsa_private_key.pem');


$name = $_POST['private_key'];
$pubfile = './key_rsa/rsa_public_key.pem'; 
$prifile = './key_rsa/rsa_private_key.pem'; 
$rsa = new RSA($pubfile, $prifile);
$ret_d = $rsa->decrypt($name);
	
    $tron = new \IEXBase\TronAPI\Tron();  
    $ec = new EC('secp256k1');
    $priv = $ec->keyFromPrivate($ret_d);
    $pubKeyHex = $priv->getPublic(false, "hex");
    $pubKeyBin = hex2bin($pubKeyHex);
    $addressHex = $tron->getAddressHex($pubKeyBin);
    $addressBin = hex2bin($addressHex);
    $addressBase58 = $tron->getBase58CheckAddress($addressBin);
   
  $fanhui=array ( 'code' => 200,
'msg' =>' ok' ,
'data' => array ( 'address' => $addressBase58 ) 
);



   
    echo json_encode($fanhui);

  

} catch (\IEXBase\TronAPI\Exception\TronException $e) {
    echo $e->getMessage();
}