<?php
// 生成RSA密钥对

if ($_GET["KEY"]=="111X"){
$config = array(
    "private_key_bits" => 2048,
    "private_key_type" => OPENSSL_KEYTYPE_RSA,
);
$res = openssl_pkey_new($config);
 
// 提取私钥
openssl_pkey_export($res, $privKey);
file_put_contents('./key_rsa/rsa_private_key.pem', $privKey);
 
// 提取公钥
$pubKey = openssl_pkey_get_details($res);
$pubKey = $pubKey["key"];
 file_put_contents('./key_rsa/rsa_public_key.pem', $pubKey);
// 打印私钥和公钥
echo "私钥：\n";
echo $privKey;
echo "\n公钥：\n";
echo $pubKey;
	
	}


?>